#include "jogo.h"
#include "raylib.h"
#include "jogador.h"
#include "inimigo.h"
#include "plataformas.h"
#include "colisoes.h"

#define MAX_PLAT 80
#define MAX_INI  80

void RodarJogo(void)
{
    int dificuldade = 10;
    int qtdPlat = 6 + dificuldade;
    int qtdIni  = 5 + dificuldade * 2;

    if (qtdPlat > MAX_PLAT) qtdPlat = MAX_PLAT;
    if (qtdIni  > MAX_INI)  qtdIni  = MAX_INI;

    // Jogador
    Jogador jogador;
    InitJogador(&jogador);

    // Chão MUITO MAIOR
    Rectangle chao = (Rectangle){ -2000, 650, 9999999, 70 };

    float gravidade = 500.0f;
    float forcaPulo = -350.0f;

    // Plataformas
    Rectangle plataformas[MAX_PLAT];
    InitPlataformas(plataformas, qtdPlat, dificuldade);

    // Inimigos
    Inimigo inimigos[MAX_INI];
    InitInimigos(inimigos, qtdIni, dificuldade);

    int dano = 0;
    int danoMax = 3;
    float cooldown = 0;

    Camera2D cam = {0};
    cam.offset = (Vector2){1280/2, 720/2};
    cam.zoom = 1.3f;

    while (!WindowShouldClose())
    {
        float dt = GetFrameTime();
        if (cooldown > 0) cooldown -= dt;

        UpdateJogador(&jogador, dt, gravidade, forcaPulo);

        cam.target = (Vector2){ jogador.caixa.x, jogador.caixa.y };

        bool descer = IsKeyDown(KEY_DOWN);

        // Colisão com chão
        ResolverColisaoChao(&jogador.caixa, &jogador.velocidade, chao, &jogador.pulando);

        // Colisão com plataformas
        ResolverColisaoPlataformas(&jogador.caixa, &jogador.velocidade,
                                   plataformas, qtdPlat, &jogador.pulando, descer);

        // Inimigos
        UpdateInimigos(inimigos, qtdIni, dt);

        for (int i = 0; i < qtdIni; i++)
        {
            if (!inimigos[i].vivo) continue;

            if (ColisaoTotal(jogador.caixa, inimigos[i].caixa))
            {
                float fundo = jogador.caixa.y + jogador.caixa.height;
                float topo = inimigos[i].caixa.y;

                // Mata inimigo com pulo
                if (fundo <= topo + 10 && jogador.velocidade.y > 0)
                {
                    inimigos[i].vivo = false;
                    jogador.velocidade.y = forcaPulo * 1.25f;  // 25% mais forte
                }
                else if (cooldown <= 0)
                {
                    dano++;
                    cooldown = 0.7f;

                    float lado = (jogador.caixa.x < inimigos[i].caixa.x) ? -1 : 1;

                    jogador.velocidade.x = lado * -250;
                    inimigos[i].velocidade.x = lado * 250;
                }
            }
        }

        if (dano >= danoMax)
            return;

        BeginDrawing();
        ClearBackground(SKYBLUE);

        BeginMode2D(cam);

        // CHÃO (verde, mas FIXO, não segue mais a câmera)
        DrawRectangleRec(chao, DARKGREEN);

        DesenharPlataformas(plataformas, qtdPlat);
        DesenharJogador(&jogador);
        DesenharInimigos(inimigos, qtdIni);

        EndMode2D();

        DrawText(TextFormat("Dano: %d / %d", dano, danoMax),
                 20, 20, 32, MAROON);

        EndDrawing();
    }
}
