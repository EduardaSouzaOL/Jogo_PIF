#include "jogador.h"
#include "raylib.h"

void InitJogador(Jogador *j)
{
    j->caixa = (Rectangle){ 100, 400, 40, 50 }; // base do player
    j->velocidade = (Vector2){ 0, 0 };
    j->pulando = false;
    j->tempoKnockback = 0.0f;
}

void UpdateJogador(Jogador *j, float dt, float gravidade, float forcaPulo)
{
    // Aplicar gravidade
    j->velocidade.y += gravidade * dt;

    // Se está em knockback, ignora controle horizontal
    if (j->tempoKnockback > 0.0f)
    {
        j->tempoKnockback -= dt;
        // desacelera um pouco o knockback
        j->velocidade.x *= 0.92f;
    }
    else
    {
        // Controle horizontal
        j->velocidade.x = 0.0f;
        if (IsKeyDown(KEY_LEFT))  j->velocidade.x = -200;
        if (IsKeyDown(KEY_RIGHT)) j->velocidade.x =  200;

        // Pulo
        if ((IsKeyPressed(KEY_SPACE) || IsKeyPressed(KEY_UP)) && !j->pulando)
        {
            j->velocidade.y = forcaPulo;
            j->pulando = true;
        }
    }

    // Aplicar movimento
    j->caixa.x += j->velocidade.x * dt;
    j->caixa.y += j->velocidade.y * dt;
}

void DesenharJogador(const Jogador *j)
{
    DrawRectangleRec(j->caixa, BLUE);
}
