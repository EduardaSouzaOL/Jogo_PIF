#include "plataformas.h"
#include "raylib.h"

void InitPlataformas(Rectangle *p, int qtd, int dificuldade)
{
    for (int i = 0; i < qtd; i++)
    {
        p[i].x = 400 + i * 350;
        p[i].y = 450 - (i % 3) * 120;
        p[i].width  = 180;
        p[i].height = 25;
    }
}

void DesenharPlataformas(Rectangle *p, int qtd)
{
    for (int i = 0; i < qtd; i++)
        DrawRectangleRec(p[i], BROWN);  // plataformas marrons
}
