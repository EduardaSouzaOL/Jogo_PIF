#include "inimigo.h"

void IniciarInimigos(Inimigo *i, int qtd, int dificuldade)
{
    for (int n = 0; n < qtd; n++)
    {
        float px = 600 + n * 500;

        i[n].caixa = (Rectangle){ px, 605, 40, 45 };
        i[n].velocidade.x = (n % 2 == 0 ? -60 : 60);
        i[n].velocidade.y = 0;

        i[n].xMin = px - 120;
        i[n].xMax = px + 120;

        i[n].vivo = true;
    }
}

void AtualizarInimigos(Inimigo *i, int qtd, float dt)
{
    for (int n = 0; n < qtd; n++)
    {
        if (!i[n].vivo) continue;

        i[n].caixa.x += i[n].velocidade.x * dt;

        if (i[n].caixa.x < i[n].xMin)
            i[n].velocidade.x = 60;

        if (i[n].caixa.x > i[n].xMax)
            i[n].velocidade.x = -60;
    }
}

void DesenharInimigos(Inimigo *i, int qtd)
{
    for (int n = 0; n < qtd; n++)
        if (i[n].vivo)
            DrawRectangleRec(i[n].caixa, RED);
}
