#ifndef JOGO_H
#define JOGO_H

void RodarJogo(void);

#endif
