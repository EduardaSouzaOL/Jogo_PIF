#ifndef INIMIGO_H
#define INIMIGO_H

#include "raylib.h"
#include <stdbool.h>

typedef struct Inimigo {
    Rectangle caixa;
    Vector2 velocidade;
    bool vivo;
    float xMin, xMax;
} Inimigo;

void IniciarInimigos(Inimigo *i, int qtd, int dificuldade);
void AtualizarInimigos(Inimigo *i, int qtd, float dt);
void DesenharInimigos(Inimigo *i, int qtd);

#endif
