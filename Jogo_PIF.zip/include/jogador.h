#ifndef JOGADOR_H
#define JOGADOR_H

#include "raylib.h"
#include <stdbool.h>

typedef struct Jogador {
    Rectangle caixa;
    Vector2  velocidade;
    bool     pulando;
    float    tempoKnockback;  // tempo restante de knockback
} Jogador;

void InitJogador(Jogador *j);
void UpdateJogador(Jogador *j, float dt, float gravidade, float forcaPulo);
void DesenharJogador(const Jogador *j);

#endif
